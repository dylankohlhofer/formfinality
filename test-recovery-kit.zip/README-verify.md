# verify.mjs — what it is and how to read it

Replays the conformance vectors against the browser build. The browser-side twin of
`swift test`: same recorded cases, same specification, so the two can't drift.

```bash
node verify.mjs                      # default build
node verify.mjs path/to/build.html   # a specific build
```

Exit 0 = every vector matches.

## Why it exists

The original 17 test suites lived only in an ephemeral sandbox and were lost when it reset.
The **vectors survived**, and they hold the valuable half — the expected outputs. This
harness is a better shape than what it replaces: one file, one source of truth, shared with
the Swift tests.

## Known state on first run

It currently reports **~3,789 passing, 23 divergences**. They are not all equal, and the
distinction matters:

| Section | Divergences | Assessment |
|---|---|---|
| `aspect` | 2 | **Harness.** The original picked a specific demo frame; this harness guesses `frames[1]`. Fix by finding the frame that reproduces 102.55°. |
| `evaluatorScenarios` | 11 | **Harness.** Timeline semantics (`action:"arm"` / `"check"` placement and frame indexing) need reconciling against the recorded checkpoints. |
| `scoreTarget` | 10 | **Investigate.** `hipAlign@learning` reads 79.07 where the vector says 80.12 — a 1.3% gap, just outside the recorded tolerance of 1.0. Clustered on one target at one tier, which suggests a real (small) change rather than noise. |
| `frameRate` | skipped | Not replayable: these rows record probes from a scripted scenario whose generator didn't survive. The property they protect is still covered by `filters`. |

**Resolve the `scoreTarget` cluster first** — it's the only one that might be a genuine
behavioural change. If the current build is correct, regenerate the vectors deliberately and
note why. If the vectors are correct, the build has drifted.

This is exactly the kind of task to hand to Claude Code with the repo in front of it.

## What it covers

`scoreTarget` (1,428) · `readMetric` (169) · `filters` (24) · `tempo` (120) ·
`neededJoints` (21) · `framing` (7) · `tintDerivation` (68) · `tintScenarios` (3) ·
`planExpansion` (15) · `aspect` (3) · `slug` (4) · `repScenarios` (3) ·
`evaluatorScenarios` (14) · content integrity (5)

## What it does *not* cover

The UI shell — every bug in reviews #17, #19, #21, #22, #23 and #31 lived there, and none
would be caught here. A manual smoke pass remains its only test.
